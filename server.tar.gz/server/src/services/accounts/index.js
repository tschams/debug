import { ApolloServer } from "apollo-server";
import { applyMiddleware } from "graphql-middleware"
import { buildFederatedSchema } from "@apollo/federation";

import permissions from "./permissions";
import resolvers from "./resolvers";
import typeDefs from "./typeDefs";

const { PrismaClient } = require('@prisma/client');
const prisma_db = new PrismaClient();

  
(async () => {
    const port = process.env.ACCOUNTS_SERVICE_PORT;
  
    const schema = applyMiddleware(
      buildFederatedSchema([{ typeDefs, resolvers }]),
      permissions
    );
    console.log("Prisma now accessible " + prisma_db);
    
    const server = new ApolloServer({
      schema,
      context: ({ req }) => {
        const user = req.headers.user ? JSON.parse(req.headers.user) : null;
        return { user, db:prisma_db };
      }
    });
  
    const { url } = await server.listen({ port });
    console.log(`Accounts service ready at ${url}`);
  })();
  
  // (async () => {
//   const port = process.env.ACCOUNTS_SERVICE_PORT;

//   const server = new ApolloServer({
//     schema: buildFederatedSchema([{ typeDefs, resolvers }]),
//     context: ({ req }) => {
//         const user = req.headers.user ? JSON.parse(req.headers.user) : null;
//         console.log(user);
//         return { user };
//     }
//   });


//     const { url } = await server.listen({ port });
//     console.log(`Accounts service ready at ${url}`);
//   })();
